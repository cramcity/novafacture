NovaFacture — free invoice & quote templates / modèles gratuits de facture et de devis

EN: Invoice-and-Quote-Template-EN.xlsx — fill in the yellow cells; totals and tax are calculated.
FR : Modeles-Facture-et-Devis-FR.xlsx — Québec (TPS + TVQ), 1 taxe (TVA…), devis.

Online generator (PDF, free): https://cramcity.github.io/novafacture/
Freelance Business Kit (EN): https://cramcity.github.io/novafacture/en/kit.html
Kit Freelance Pro (FR) : https://cramcity.github.io/novafacture/kit.html

Free to use for your own business. Redistribution or resale of the templates is not allowed.
